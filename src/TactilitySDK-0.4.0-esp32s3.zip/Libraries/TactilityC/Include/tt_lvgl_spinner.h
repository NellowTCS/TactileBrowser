#pragma once

#include <lvgl.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Create a spinner widget. */
lv_obj_t* tt_lvgl_spinner_create(lv_obj_t* parent);

#ifdef __cplusplus
}
#endif